﻿using System;

namespace AssetStudio
{
    public class StreamingInfo
    {
        public long offset; //ulong
        public uint size;
        public string path;

        public StreamingInfo() { }

        public StreamingInfo(ObjectReader reader)
        {
            var version = reader.version;

            if (version[0] >= 2020) //2020.1 and up
            {
                offset = reader.ReadInt64();
            }
            else
            {
                offset = reader.ReadUInt32();
            }
            size = reader.ReadUInt32();
            path = reader.ReadAlignedString();
        }
    }

    public class GLTextureSettings
    {
        public int m_FilterMode;
        public int m_Aniso;
        public float m_MipBias;
        public int m_WrapMode;

        public GLTextureSettings() { }

        public GLTextureSettings(ObjectReader reader)
        {
            var version = reader.version;

            m_FilterMode = reader.ReadInt32();
            m_Aniso = reader.ReadInt32();
            m_MipBias = reader.ReadSingle();
            if (version[0] >= 2017)//2017.x and up
            {
                m_WrapMode = reader.ReadInt32(); //m_WrapU
                int m_WrapV = reader.ReadInt32();
                int m_WrapW = reader.ReadInt32();
            }
            else
            {
                m_WrapMode = reader.ReadInt32();
            }
        }
    }

    public sealed class Texture2D : Texture
    {
        public int m_Width;
        public int m_Height;
        public TextureFormat m_TextureFormat;
        public bool m_MipMap;
        public int m_MipCount;
        public GLTextureSettings m_TextureSettings;
        public ResourceReader image_data;
        public StreamingInfo m_StreamData;

        public Texture2D(ObjectReader reader) : base(reader)
        {
            m_Width = reader.ReadInt32();
            m_Height = reader.ReadInt32();
            var m_CompleteImageSize = reader.ReadInt32();
            if (version[0] >= 2020) //2020.1 and up
            {
                var m_MipsStripped = reader.ReadInt32();
            }
            m_TextureFormat = (TextureFormat)reader.ReadInt32();
            if (version[0] < 5 || (version[0] == 5 && version[1] < 2)) //5.2 down
            {
                m_MipMap = reader.ReadBoolean();
            }
            else
            {
                m_MipCount = reader.ReadInt32();
            }
            //Unity 6: the middle of Texture2D changes between minor versions (6000.0 -> 6000.3),
            //so locate the image data from the end of the object, where its layout is stable.
            if (version[0] >= 6000 && TryReadImageDataFromEnd(reader, m_CompleteImageSize))
            {
                return;
            }
            if (version[0] > 2 || (version[0] == 2 && version[1] >= 6)) //2.6.0 and up
            {
                var m_IsReadable = reader.ReadBoolean();
            }
            if (version[0] >= 2020) //2020.1 and up
            {
                var m_IsPreProcessed = reader.ReadBoolean();
            }
            if (version[0] > 2019 || (version[0] == 2019 && version[1] >= 3)) //2019.3 and up
            {
                var m_IgnoreMasterTextureLimit = reader.ReadBoolean(); //renamed m_IgnoreMipmapLimit in 2022.2
            }
            if (version[0] > 2022 || (version[0] == 2022 && version[1] >= 2)) //2022.2 and up (Unity 6 incluido)
            {
                reader.AlignStream();
                var m_MipmapLimitGroupName = reader.ReadAlignedString();
            }
            if (version[0] >= 3) //3.0.0 - 5.4
            {
                if (version[0] < 5 || (version[0] == 5 && version[1] <= 4))
                {
                    var m_ReadAllowed = reader.ReadBoolean();
                }
            }
            if (version[0] > 2018 || (version[0] == 2018 && version[1] >= 2)) //2018.2 and up
            {
                var m_StreamingMipmaps = reader.ReadBoolean();
            }
            reader.AlignStream();
            if (version[0] > 2018 || (version[0] == 2018 && version[1] >= 2)) //2018.2 and up
            {
                var m_StreamingMipmapsPriority = reader.ReadInt32();
            }
            var m_ImageCount = reader.ReadInt32();
            var m_TextureDimension = reader.ReadInt32();
            m_TextureSettings = new GLTextureSettings(reader);
            if (version[0] >= 3) //3.0 and up
            {
                var m_LightmapFormat = reader.ReadInt32();
            }
            if (version[0] > 3 || (version[0] == 3 && version[1] >= 5)) //3.5.0 and up
            {
                var m_ColorSpace = reader.ReadInt32();
            }
            if (version[0] > 2020 || (version[0] == 2020 && version[1] >= 2)) //2020.2 and up
            {
                var m_PlatformBlob = reader.ReadUInt8Array();
                reader.AlignStream();
            }
            var image_data_size = reader.ReadInt32();
            if (image_data_size == 0 && ((version[0] == 5 && version[1] >= 3) || version[0] > 5))//5.3.0 and up
            {
                m_StreamData = new StreamingInfo(reader);
            }

            ResourceReader resourceReader;
            if (!string.IsNullOrEmpty(m_StreamData?.path))
            {
                resourceReader = new ResourceReader(m_StreamData.path, assetsFile, m_StreamData.offset, m_StreamData.size);
            }
            else
            {
                resourceReader = new ResourceReader(reader, reader.BaseStream.Position, image_data_size);
            }
            image_data = resourceReader;
        }

        //Layout at the end of a Unity 6 Texture2D:
        //  ... image data (int32 length + bytes, aligned) | m_StreamData: offset (UInt64), size (UInt32), path (aligned string)
        private bool TryReadImageDataFromEnd(ObjectReader reader, int completeImageSize)
        {
            var start = reader.Position;
            var objStart = reader.byteStart;
            var objEnd = reader.byteStart + reader.byteSize;
            try
            {
                var minPos = Math.Max(start, objEnd - 4096);
                for (var pos = objEnd - 16; pos >= minPos; pos -= 4)
                {
                    reader.Position = pos;
                    var offset = reader.ReadInt64();
                    var size = reader.ReadUInt32();
                    var pathLength = reader.ReadInt32();
                    if (pathLength < 0 || pathLength > 1024)
                    {
                        continue;
                    }
                    var relEnd = ((pos - objStart) + 16 + pathLength + 3) & ~3L;
                    if (relEnd != reader.byteSize)
                    {
                        continue;
                    }
                    if (pathLength == 0)
                    {
                        //Image data stored inside the object
                        if (offset != 0 || size != 0 || completeImageSize <= 0)
                        {
                            continue;
                        }
                        var alignedLength = (completeImageSize + 3) & ~3L;
                        var lengthPos = pos - alignedLength - 4;
                        if (lengthPos < start)
                        {
                            continue;
                        }
                        reader.Position = lengthPos;
                        if (reader.ReadInt32() != completeImageSize)
                        {
                            continue;
                        }
                        m_TextureSettings = new GLTextureSettings();
                        image_data = new ResourceReader(reader, lengthPos + 4, completeImageSize);
                        return true;
                    }
                    else
                    {
                        //Image data stored in an external .resS file
                        if (size == 0 || offset < 0)
                        {
                            continue;
                        }
                        var bytes = reader.ReadBytes(pathLength);
                        if (bytes.Length != pathLength || Array.Exists(bytes, b => b < 0x20 || b > 0x7E))
                        {
                            continue;
                        }
                        m_StreamData = new StreamingInfo
                        {
                            offset = offset,
                            size = size,
                            path = System.Text.Encoding.UTF8.GetString(bytes)
                        };
                        m_TextureSettings = new GLTextureSettings();
                        image_data = new ResourceReader(m_StreamData.path, assetsFile, m_StreamData.offset, m_StreamData.size);
                        return true;
                    }
                }
            }
            catch
            {
                //fall back to sequential reading
            }
            reader.Position = start;
            return false;
        }
    }

    public enum TextureFormat
    {
        Alpha8 = 1,
        ARGB4444,
        RGB24,
        RGBA32,
        ARGB32,
        ARGBFloat,
        RGB565,
        BGR24,
        R16,
        DXT1,
        DXT3,
        DXT5,
        RGBA4444,
        BGRA32,
        RHalf,
        RGHalf,
        RGBAHalf,
        RFloat,
        RGFloat,
        RGBAFloat,
        YUY2,
        RGB9e5Float,
        RGBFloat,
        BC6H,
        BC7,
        BC4,
        BC5,
        DXT1Crunched,
        DXT5Crunched,
        PVRTC_RGB2,
        PVRTC_RGBA2,
        PVRTC_RGB4,
        PVRTC_RGBA4,
        ETC_RGB4,
        ATC_RGB4,
        ATC_RGBA8,
        EAC_R = 41,
        EAC_R_SIGNED,
        EAC_RG,
        EAC_RG_SIGNED,
        ETC2_RGB,
        ETC2_RGBA1,
        ETC2_RGBA8,
        ASTC_RGB_4x4,
        ASTC_RGB_5x5,
        ASTC_RGB_6x6,
        ASTC_RGB_8x8,
        ASTC_RGB_10x10,
        ASTC_RGB_12x12,
        ASTC_RGBA_4x4,
        ASTC_RGBA_5x5,
        ASTC_RGBA_6x6,
        ASTC_RGBA_8x8,
        ASTC_RGBA_10x10,
        ASTC_RGBA_12x12,
        ETC_RGB4_3DS,
        ETC_RGBA8_3DS,
        RG16,
        R8,
        ETC_RGB4Crunched,
        ETC2_RGBA8Crunched,
        ASTC_HDR_4x4,
        ASTC_HDR_5x5,
        ASTC_HDR_6x6,
        ASTC_HDR_8x8,
        ASTC_HDR_10x10,
        ASTC_HDR_12x12,
        RG32,
        RGB48,
        RGBA64,
        //2023.2 / Unity 6
        R8_SIGNED,
        RG16_SIGNED,
        RGB24_SIGNED,
        RGBA32_SIGNED,
        R16_SIGNED,
        RG32_SIGNED,
        RGB48_SIGNED,
        RGBA64_SIGNED
    }
}