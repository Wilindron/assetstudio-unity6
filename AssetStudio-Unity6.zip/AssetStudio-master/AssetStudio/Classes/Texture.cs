﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AssetStudio
{
    public abstract class Texture : NamedObject
    {
        protected Texture(ObjectReader reader) : base(reader)
        {
            if (version[0] >= 6000 && type == ClassIDType.Texture2D) //Unity 6
            {
                var m_ForcedFallbackFormat = reader.ReadInt32();
                //Unity 6000.3 (validated with real data): m_Width follows m_ForcedFallbackFormat directly.
                //Other Unity 6 versions may still have the two fallback bools + align, so detect it.
                if (!LooksLikeTexture2DHeader(reader))
                {
                    var m_DownscaleFallback = reader.ReadBoolean();
                    var m_IsAlphaChannelOptional = reader.ReadBoolean();
                    reader.AlignStream();
                }
            }
            else if (version[0] > 2017 || (version[0] == 2017 && version[1] >= 3)) //2017.3 and up
            {
                var m_ForcedFallbackFormat = reader.ReadInt32();
                var m_DownscaleFallback = reader.ReadBoolean();
                if (version[0] > 2020 || (version[0] == 2020 && version[1] >= 2)) //2020.2 and up
                {
                    var m_IsAlphaChannelOptional = reader.ReadBoolean();
                }
                reader.AlignStream();
            }
        }

        //Peeks m_Width, m_Height, m_CompleteImageSize, m_MipsStripped, m_TextureFormat, m_MipCount
        private static bool LooksLikeTexture2DHeader(ObjectReader reader)
        {
            var pos = reader.Position;
            try
            {
                if (pos + 24 > reader.byteStart + reader.byteSize)
                {
                    return false;
                }
                var width = reader.ReadInt32();
                var height = reader.ReadInt32();
                var completeImageSize = reader.ReadInt32();
                var mipsStripped = reader.ReadInt32();
                var format = reader.ReadInt32();
                var mipCount = reader.ReadInt32();
                return width > 0 && width <= 32768
                    && height > 0 && height <= 32768
                    && completeImageSize >= 0
                    && mipsStripped >= 0 && mipsStripped < 32
                    && format > 0 && format < 256
                    && mipCount > 0 && mipCount <= 32;
            }
            catch
            {
                return false;
            }
            finally
            {
                reader.Position = pos;
            }
        }
    }
}
